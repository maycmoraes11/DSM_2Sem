/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.objeto1;

/**
 *
 * @author mayco
 */

public class Objeto1 {

    public static void main(String[] args) {
        Videogame vg = new Videogame();
        vg.marca = "xbox";
        vg.cor = "branca";
        vg.armazenamento = "512";
        vg.estado = "usado";
        vg.funcionando = true;
        vg.caracteristicas();
    }
}
