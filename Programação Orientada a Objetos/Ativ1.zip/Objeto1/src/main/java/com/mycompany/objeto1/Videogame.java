/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.objeto1;

/**
 *
 * @author mayco
 */
public class Videogame {
    String marca;
    String cor;
    String armazenamento;
    String estado;
    boolean funcionando;
    
    void caracteristicas(){
        System.out.println ("Marca do aparelho: "+ this.marca);
        System.out.println ("Cor do aparelho: "+ this.cor);
        System.out.println ("Armazenamento do aparelho: "+ this.armazenamento);
        System.out.println ("Estado do aparelho: "+ this.estado);
        System.out.println ("O aparelho está funcionando: "+ this.funcionando);       
    } 
}
