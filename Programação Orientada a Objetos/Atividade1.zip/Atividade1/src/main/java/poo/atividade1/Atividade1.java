/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package poo.atividade1;

/**
 *
 * @author Alunos
 */
public class Atividade1 {

    public static void main(String[] args) {
        ContaBancaria cb1 = new ContaBancaria("Lóide");
        cb1.depositar(200);
        cb1.sacar(300);
        cb1.sacar(100);
        cb1.status();
        
        
    }
    
}
