/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.atividade1;

/**
 *
 * @author Alunos
 */
public class ContaBancaria {
    private double saldo;
    private String titular;

    public ContaBancaria (String n) {
        this.titular = n;
        this.saldo = 0;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        if (saldo >0) {
          this.saldo = saldo;  
        } else {
            System.out.println("O saldo deve ser maior que zero!");
        }
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        if(!titular.isBlank() && titular != null) {
        this.titular = titular;
    } else {
            System.out.println("O nome não deve ser vazio!");
        }
    }
    
    public void depositar(double valor) {
        if (valor <= 0){
            System.out.println(" O valor deve ser maior que zero!");
        } else {
            setSaldo(valor + getSaldo());
            System.out.println("O saldo atual é de: " +getSaldo());
        }
    }
    
    public void sacar(double valor) {
        if (valor <= getSaldo()) {
            setSaldo(getSaldo() - valor);
        } else {
            System.out.println(" O seu saldo é insuficiente! ");
        }
    }
     public void status() {
         System.out.println("O saldo é: " +getSaldo());
         System.out.println("O nome do titular é: " +getTitular());
    }         
}


